import json
import logging 
import boto3
from ingestion_framework.start import trigger

logger = logging.getLogger(__file__)


def lambda_handler(event, context):
    logger.info(event)
    logger.info('## INITIATED BY EVENT: ')

    print(event)
    
    
    trigger(json.loads(event))
        
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
